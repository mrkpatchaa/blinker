const electron = require('electron')
const {app, Tray, Menu} = require('electron')
const notifier = require('node-notifier')
const AutoLaunch = require('auto-launch')


const path = require('path')

const appAutoLauncher = new AutoLaunch({
    name: 'Blinker',
    isHidden: true,
    mac: {
        useLaunchAgent: true
    }
})

const TIMER_LABEL_STOPPED = 'Start the timer'
const TIMER_LABEL_STARTED = 'Stop the timer'

// Our global objects
let mainWindow
let timerStarted
let launchOnStartup = true
let playSound = true
let timer
let maxExpositionTime = 20 * 60 * 1000
let breakTime = 20 * 1000

// Define our tray item
let tray = null
let contextMenu = null

function launchApplication() {
    // Setup the menubar with an icon
    tray = new Tray(path.join(__dirname, 'icons/tray.png'))

    contextMenu = Menu.buildFromTemplate([
        {
            label: TIMER_LABEL_STARTED,
            type: 'checkbox',
            sublabel: 'Click to toggle timer',
            click () {
                toggleTimer()
            }
        },
        {type: 'separator'},
        {
            type: 'checkbox',
            label: 'Launch the application on system startup',
            sublabel: 'If this option is enabled, application will start on system startup',
            checked: launchOnStartup,
            click () {
                toggleStartup()
            }
        },
        {type: 'separator'},
        {
            type: 'checkbox',
            label: 'Play sounds with notifications',
            sublabel: 'If this option is enabled, a sound will be played on every notification',
            checked: playSound,
            click () {
                toggleSound()
            }
        },
        {type: 'separator'},
        {
            role: 'quit',
            label: 'Quit application'
        }
    ])

    tray.setToolTip('Click to see the magic.')

    tray.setContextMenu(contextMenu)

    // Start our timer
    startTimer()

    // Enable launch on startup by default
    appAutoLauncher.isEnabled()
        .then(function (isEnabled) {
            if (isEnabled) {
                return;
            }
            appAutoLauncher.enable();
        })
        .catch(function (err) {
        })
}

function toggleStartup() {
    if (launchOnStartup) {
        appAutoLauncher.enable()
            .then(function () {
                notifyLaunchChanged()
            })
            .catch(function (err) {
            })
    }
    else {
        appAutoLauncher.disable()
            .then(function () {
                notifyLaunchChanged()
            })
            .catch(function (err) {
            })
    }
}

function notifyLaunchChanged() {
    notifier.notify({
        title: 'Startup status changed',
        message: launchOnStartup ? 'You will have to launch the application every time you log in' : 'Gret! Application will launch on application startup',
        icon: path.join(__dirname, 'icons/eye.png'),
        contentImage: '',
        sound: playSound
    })
    launchOnStartup = !launchOnStartup
    contextMenu.items[2].checked = launchOnStartup
    tray.setContextMenu(contextMenu)
}

function toggleTimer() {
    if (timerStarted) {
        stopTimer()
        contextMenu.items[0].label = TIMER_LABEL_STOPPED
    }
    else {
        startTimer()
        contextMenu.items[0].label = TIMER_LABEL_STARTED
    }
    tray.setContextMenu(contextMenu)
}

function toggleSound() {
    playSound = !playSound
}

function startTimer() {
    timerStarted = true
    timer = setTimeout(function () {
        takeABreak()
    }, maxExpositionTime);
}

function stopTimer() {
    timerStarted = false
    clearTimeout(timer)
}

function takeABreak() {
    stopTimer()

    notifier.notify({
        title: 'Take a break !',
        message: 'Great! Application will launch on application startup',
        icon: path.join(__dirname, 'icons/eye.png'),
        contentImage: '',
        sound: playSound
    })

    setTimeout(function () {
        notifier.notify({
            title: 'Go back to work !',
            message: 'Great! Application will launch on application startup',
            icon: path.join(__dirname, 'icons/eye.png'),
            contentImage: '',
            sound: playSound
        })
        startTimer()
    }, breakTime)
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', launchApplication)

// Quit when all windows are closed.
app.on('window-all-closed', function () {
    // On OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
        app.quit()
    }
})

app.on('activate', function () {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (mainWindow === null) {
        createTray()
    }
})
